STRAPDON IN-PLAY SAFARI MVP

Open index.html in a browser to use the manual dashboard. It uses no server, account, Python or paid API.

On iPhone, Safari may not reliably open locally downloaded HTML files as fully functioning web pages. For the best experience, host index.html on a free static HTTPS host such as GitHub Pages or Cloudflare Pages. Then open the public HTTPS URL in Safari and choose Share > Add to Home Screen.

GitHub Pages outline:
1. Create a free GitHub account.
2. Create a public repository, e.g. strapdon-inplay.
3. Upload index.html to the repository root.
4. In repository Settings > Pages, choose Deploy from a branch, main, /(root), and save.
5. Open the published HTTPS link when GitHub reports deployment complete.

Important: GitHub Pages makes the app's source code public. The app does not upload your entered records; those are kept in browser localStorage on the device and origin. Never put Telegram API keys, sessions, or private credentials in the HTML or public repository. The private Telegram invitation is not embedded as a working API connection.

Features: six sports, manual Telegram tip entry and basic parsing, bookmaker odds comparison, expected value calculator, tipster win rate/ROI leaderboard, manual paper settlement, export/import JSON.

Limitations: no live Telegram scraping, live odds, trained AI model, automatic result verification, push notifications, or sync across devices. Probability is user-entered, not a forecast. Data can disappear if browser storage is cleared; export backups.
